NOTE:
You need to have your card saved on throne. To do this, sign up to Link.com with the email address you used to sign up to Throne. Save your card details. You can do this from Throne's checkout page.


HOW TO USE THIS CHROME EXTENSION:
1. Unzip this folder
2. Open Chrome
3. Go to chrome://extensions/
4. Enable "Developer Mode" (Top right corner, toggle ON)
5. Click "Load Unpacked"
6. Select the unzipped folder
7. Go to: https://throne.com/send2syn/item/e9084133-c957-4092-83b5-f8fdb65a999e
8. DO NOT TOUCH ANYTHING

Please note that Syn is not responsible for any charges, losses, or issues resulting in the use of this extension. Happy testing~




