(async function tributeLoop() {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  async function clickSelector(selector, timeout = 10000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const btn = document.querySelector(selector);
      if (btn) {
        btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        btn.click();
        return true;
      }
      await sleep(500);
    }
    return false;
  }

  while (true) {
    console.log("🔁 Starting Syn Tribute Loop");

    // Step 1: Wait for Add to Cart and click
    console.log("🛒 Clicking Add to Cart");
    await clickSelector('.chakra-button.css-ymrzfq');
    await sleep(3000);

    // Step 2: Click Checkout
    console.log("💳 Clicking Checkout");
    await clickSelector('.chakra-button.css-q1d3jr');
    await sleep(10000); // wait for checkout page to load

    // Step 3: Click Pay Now
    console.log("✅ Clicking Pay Now");
    await clickSelector('.chakra-button.css-13bpv45');
    await sleep(8000); // wait for payment to process or fail

    // Restart loop
    console.log("🔁 Looping tribute process again...");
    location.href = "https://throne.com/send2syn/item/e9084133-c957-4092-83b5-f8fdb65a999e";
    await sleep(10000);
  }
})();